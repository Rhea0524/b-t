package com.example.budgettrackerapp.data.repository

import com.example.budgettrackerapp.data.dao.BudgetDao
import com.example.budgettrackerapp.data.entities.Budget
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class BudgetRepository @Inject constructor(
    private val budgetDao: BudgetDao
) {
    suspend fun insertBudget(budget: Budget) = 
        budgetDao.insertBudget(budget)
    
    suspend fun updateBudget(budget: Budget) = 
        budgetDao.updateBudget(budget)
    
    suspend fun deleteBudget(budget: Budget) = 
        budgetDao.deleteBudget(budget)
    
    fun getBudgetsForMonth(userId: Long, monthYear: String): Flow<List<Budget>> = 
        budgetDao.getBudgetsForMonth(userId, monthYear)
    
    fun getBudgetByCategory(userId: Long, category: String, monthYear: String): Flow<Budget?> = 
        budgetDao.getBudgetByCategory(userId, category, monthYear)
    
    fun getTotalBudgetForMonth(userId: Long, monthYear: String): Flow<Double?> = 
        budgetDao.getTotalBudgetForMonth(userId, monthYear)
}