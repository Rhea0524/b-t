package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.data.entities.Transaction
import com.example.budgettrackerapp.data.entities.TransactionType
import com.example.budgettrackerapp.databinding.FragmentAddTransactionBinding
import com.example.budgettrackerapp.ui.viewmodel.TransactionViewModel
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import com.google.android.material.datepicker.MaterialDatePicker
import dagger.hilt.android.AndroidEntryPoint
import java.util.Date

@AndroidEntryPoint
class AddTransactionFragment : BaseFragment<FragmentAddTransactionBinding>() {
    
    private val transactionViewModel: TransactionViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()
    private var selectedDate: Date = Date()

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentAddTransactionBinding = 
        FragmentAddTransactionBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupCategoryDropdown()
        setupDatePicker()
        setupSaveButton()
    }

    private fun setupCategoryDropdown() {
        val categories = listOf(
            "Food & Dining",
            "Transportation",
            "Shopping",
            "Bills & Utilities",
            "Entertainment",
            "Health & Fitness",
            "Travel",
            "Salary",
            "Investment",
            "Other"
        )
        
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            categories
        )
        
        binding.categoryInput.setAdapter(adapter)
    }

    private fun setupDatePicker() {
        binding.datePickerButton.setOnClickListener {
            val picker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Date")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build()

            picker.addOnPositiveButtonClickListener { timestamp ->
                selectedDate = Date(timestamp)
                binding.datePickerButton.text = android.text.format.DateFormat
                    .getDateFormat(requireContext())
                    .format(selectedDate)
            }

            picker.show(parentFragmentManager, "date_picker")
        }
    }

    private fun setupSaveButton() {
        binding.saveButton.setOnClickListener {
            val description = binding.descriptionInput.text.toString()
            val amount = binding.amountInput.text.toString().toDoubleOrNull() ?: 0.0
            val category = binding.categoryInput.text.toString()
            val type = if (binding.typeExpense.isChecked) 
                TransactionType.EXPENSE else TransactionType.INCOME

            if (validateInput(description, amount, category)) {
                saveTransaction(description, amount, category, type)
            }
        }
    }

    private fun validateInput(
        description: String,
        amount: Double,
        category: String
    ): Boolean {
        var isValid = true

        if (description.isBlank()) {
            binding.descriptionLayout.error = "Description is required"
            isValid = false
        }

        if (amount <= 0) {
            binding.amountLayout.error = "Amount must be greater than 0"
            isValid = false
        }

        if (category.isBlank()) {
            binding.categoryLayout.error = "Category is required"
            isValid = false
        }

        return isValid
    }

    private fun saveTransaction(
        description: String,
        amount: Double,
        category: String,
        type: TransactionType
    ) {
        userViewModel.currentUser.value?.let { user ->
            val transaction = Transaction(
                userId = user.userId,
                description = description,
                amount = amount,
                category = category,
                type = type,
                date = selectedDate
            )
            
            transactionViewModel.addTransaction(transaction)
            findNavController().navigateUp()
        }
    }
}