package com.example.budgettrackerapp.data.dao

import androidx.room.*
import com.example.budgettrackerapp.data.entities.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: User): Long

    @Update
    suspend fun updateUser(user: User)

    @Delete
    suspend fun deleteUser(user: User)

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): User?

    @Query("SELECT * FROM users WHERE userId = :userId")
    fun getUserById(userId: Long): Flow<User>

    @Query("SELECT * FROM users WHERE userId = :userId")
    fun getUserFlow(userId: Long): Flow<User?>

    @Query("SELECT * FROM users WHERE userId = :userId")
    suspend fun getUser(userId: Long): User?

    @Query("UPDATE users SET darkModeEnabled = :enabled WHERE userId = :userId")
    suspend fun updateDarkMode(userId: Long, enabled: Boolean)

    @Query("UPDATE users SET notificationsEnabled = :enabled WHERE userId = :userId")
    suspend fun updateNotifications(userId: Long, enabled: Boolean)

    @Query("UPDATE users SET currency = :currency WHERE userId = :userId")
    suspend fun updateCurrency(userId: Long, currency: String)

    @Query("UPDATE users SET displayName = :displayName WHERE userId = :userId")
    suspend fun updateDisplayName(userId: Long, displayName: String)

    @Query("UPDATE users SET email = :email WHERE userId = :userId")
    suspend fun updateEmail(userId: Long, email: String?)
}