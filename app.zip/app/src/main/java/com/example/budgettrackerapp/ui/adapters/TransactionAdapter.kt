package com.example.budgettrackerapp.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.data.entities.Transaction
import com.example.budgettrackerapp.data.entities.TransactionType
import com.example.budgettrackerapp.databinding.ItemTransactionBinding
import com.example.budgettrackerapp.utils.Utils

class TransactionAdapter : ListAdapter<Transaction, TransactionAdapter.TransactionViewHolder>(TransactionDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class TransactionViewHolder(
        private val binding: ItemTransactionBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(transaction: Transaction) {
            binding.apply {
                transactionDescription.text = transaction.description
                transactionCategory.text = transaction.category
                transactionDate.text = Utils.formatDate(transaction.date)

                val amount = when (transaction.type) {
                    TransactionType.EXPENSE -> -transaction.amount
                    TransactionType.INCOME -> transaction.amount
                }
                
                transactionAmount.text = Utils.formatCurrency(amount)
                transactionAmount.setTextColor(
                    itemView.context.getColor(
                        if (amount >= 0) R.color.income_green else R.color.expense_red
                    )
                )
            }
        }
    }

    private class TransactionDiffCallback : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Transaction, newItem: Transaction): Boolean {
            return oldItem == newItem
        }
    }
}