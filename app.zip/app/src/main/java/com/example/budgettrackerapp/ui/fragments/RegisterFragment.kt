package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.databinding.FragmentRegisterBinding
import com.example.budgettrackerapp.ui.viewmodel.AuthViewModel
import com.example.budgettrackerapp.utils.Result
import com.example.budgettrackerapp.utils.Validator
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RegisterFragment : Fragment() {
    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonRegister.setOnClickListener {
            val username = binding.editTextUsername.text.toString()
            val displayName = binding.editTextDisplayName.text.toString()
            val email = binding.editTextEmail.text.toString()
            val password = binding.editTextPassword.text.toString()
            val confirmPassword = binding.editTextConfirmPassword.text.toString()

            when {
                username.isBlank() || password.isBlank() || confirmPassword.isBlank() -> {
                    Toast.makeText(context, "Please fill all required fields", Toast.LENGTH_SHORT).show()
                }
                password != confirmPassword -> {
                    Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
                email.isNotBlank() && !Validator.validateEmail(email).isSuccess() -> {
                    Toast.makeText(context, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    setLoading(true)
                    viewModel.register(
                        username = username,
                        password = password,
                        email = email.takeIf { it.isNotBlank() },
                        displayName = displayName.takeIf { it.isNotBlank() }
                    )
                }
            }
        }

        binding.textViewLogin.setOnClickListener {
            findNavController().navigateUp()
        }

        viewModel.registrationResult.observe(viewLifecycleOwner) { result ->
            setLoading(false)
            when (result) {
                is Result.Success -> {
                    Toast.makeText(context, "Registration successful", Toast.LENGTH_SHORT).show()
                    findNavController().navigate(RegisterFragmentDirections.actionRegisterToDashboard())
                }
                is Result.Error -> {
                    Toast.makeText(context, result.exception.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.isVisible = loading
        binding.buttonRegister.isEnabled = !loading
        binding.editTextUsername.isEnabled = !loading
        binding.editTextDisplayName.isEnabled = !loading
        binding.editTextEmail.isEnabled = !loading
        binding.editTextPassword.isEnabled = !loading
        binding.editTextConfirmPassword.isEnabled = !loading
        binding.textViewLogin.isEnabled = !loading
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}