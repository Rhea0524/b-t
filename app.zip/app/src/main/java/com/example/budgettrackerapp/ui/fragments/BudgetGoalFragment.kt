package com.example.budgettrackerapp.ui.fragments

import androidx.fragment.app.Fragment

class BudgetGoalFragment : Fragment() {
    // TODO: Implement BudgetGoalFragment as per guide
}
