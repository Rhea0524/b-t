package com.example.budgettrackerapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.budgettrackerapp.data.entities.Expense
import com.example.budgettrackerapp.data.repository.ExpenseRepository
import kotlinx.coroutines.launch

class ExpenseViewModel(private val expenseRepository: ExpenseRepository) : ViewModel() {
    private val _expenseOperationResult = MutableLiveData<Result<Any>>()
    val expenseOperationResult: LiveData<Result<Any>> = _expenseOperationResult

    fun getExpensesForPeriod(userId: Long, startDate: Long, endDate: Long): LiveData<List<Expense>> {
        return expenseRepository.getExpensesForPeriod(userId, startDate, endDate)
    }

    fun addExpense(
        amount: Double,
        description: String,
        date: Long,
        startTime: Long?,
        endTime: Long?,
        photoPath: String?,
        categoryId: Long,
        userId: Long
    ) {
        viewModelScope.launch {
            val result = expenseRepository.addExpense(
                amount, description, date, startTime, endTime, photoPath, categoryId, userId
            )
            _expenseOperationResult.postValue(result)
        }
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            val result = expenseRepository.updateExpense(expense)
            _expenseOperationResult.postValue(result)
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            val result = expenseRepository.deleteExpense(expense)
            _expenseOperationResult.postValue(result)
        }
    }
}