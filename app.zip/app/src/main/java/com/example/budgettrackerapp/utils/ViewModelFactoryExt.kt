package com.example.budgettrackerapp.utils

import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.budgettrackerapp.BudgetTrackerApp
import com.example.budgettrackerapp.viewmodels.AuthViewModel
import com.example.budgettrackerapp.viewmodels.CategoryViewModel
import com.example.budgettrackerapp.viewmodels.ExpenseViewModel
import com.example.budgettrackerapp.viewmodels.BudgetGoalViewModel

/**
 * Extension function to create ViewModels with app repositories
 */
inline fun <reified T : ViewModel> Fragment.getViewModel(): T {
    val application = requireActivity().application as BudgetTrackerApp
    return ViewModelProvider(this, ViewModelProvider.Factory {
        when {
            T::class.java.isAssignableFrom(AuthViewModel::class.java) -> {
                AuthViewModel(application.userRepository) as T
            }
            T::class.java.isAssignableFrom(CategoryViewModel::class.java) -> {
                CategoryViewModel(application.categoryRepository) as T
            }
            T::class.java.isAssignableFrom(ExpenseViewModel::class.java) -> {
                ExpenseViewModel(application.expenseRepository) as T
            }
            T::class.java.isAssignableFrom(BudgetGoalViewModel::class.java) -> {
                BudgetGoalViewModel(application.budgetGoalRepository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: \\${T::class.java.name}")
        }
    })[T::class.java]
}
