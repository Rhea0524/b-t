package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.budgettrackerapp.databinding.FragmentBudgetsBinding
import com.example.budgettrackerapp.ui.adapters.BudgetAdapter
import com.example.budgettrackerapp.ui.viewmodel.BudgetViewModel
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@AndroidEntryPoint
class BudgetsFragment : BaseFragment<FragmentBudgetsBinding>() {
    
    private val budgetViewModel: BudgetViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()
    private lateinit var budgetAdapter: BudgetAdapter

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentBudgetsBinding = 
        FragmentBudgetsBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupClickListeners()
        observeData()
    }

    private fun setupRecyclerView() {
        budgetAdapter = BudgetAdapter()
        binding.budgetsList.apply {
            adapter = budgetAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    private fun setupClickListeners() {
        binding.fabAddBudget.setOnClickListener {
            findNavController().navigate(
                BudgetsFragmentDirections.actionBudgetsToAddBudget()
            )
        }
    }

    private fun observeData() {
        val currentMonth = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
        
        viewLifecycleOwner.lifecycleScope.launch {
            userViewModel.currentUser.collect { user ->
                user?.let {
                    budgetViewModel.loadBudgetsForMonth(it.userId, currentMonth)
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            budgetViewModel.budgets.collect { budgets ->
                budgetAdapter.submitList(budgets)
            }
        }
    }
}