package com.example.budgettrackerapp.ui.fragments

import androidx.fragment.app.Fragment

class ExpenseDetailFragment : Fragment() {
    // TODO: Implement ExpenseDetailFragment as per guide
}
