package com.example.budgettrackerapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.budgettrackerapp.data.dao.BudgetDao
import com.example.budgettrackerapp.data.dao.TransactionDao
import com.example.budgettrackerapp.data.dao.UserDao
import com.example.budgettrackerapp.data.entities.Budget
import com.example.budgettrackerapp.data.entities.Transaction
import com.example.budgettrackerapp.data.entities.User
import com.example.budgettrackerapp.utils.Converters

@Database(
    entities = [User::class, Transaction::class, Budget::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Add new columns to users table
                database.execSQL("ALTER TABLE users ADD COLUMN email TEXT")
                database.execSQL("ALTER TABLE users ADD COLUMN displayName TEXT")
                database.execSQL("ALTER TABLE users ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD'")
                database.execSQL("ALTER TABLE users ADD COLUMN notificationsEnabled INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE users ADD COLUMN darkModeEnabled INTEGER NOT NULL DEFAULT 0")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "budget_tracker_db"
                )
                .addMigrations(MIGRATION_1_2)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}