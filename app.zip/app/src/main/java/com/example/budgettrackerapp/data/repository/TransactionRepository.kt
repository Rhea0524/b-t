package com.example.budgettrackerapp.data.repository

import com.example.budgettrackerapp.data.dao.TransactionDao
import com.example.budgettrackerapp.data.entities.Transaction
import kotlinx.coroutines.flow.Flow
import java.util.Date
import javax.inject.Inject

class TransactionRepository @Inject constructor(
    private val transactionDao: TransactionDao
) {
    suspend fun insertTransaction(transaction: Transaction) = 
        transactionDao.insertTransaction(transaction)
    
    suspend fun updateTransaction(transaction: Transaction) = 
        transactionDao.updateTransaction(transaction)
    
    suspend fun deleteTransaction(transaction: Transaction) = 
        transactionDao.deleteTransaction(transaction)
    
    fun getAllTransactionsForUser(userId: Long): Flow<List<Transaction>> = 
        transactionDao.getAllTransactionsForUser(userId)
    
    fun getTransactionsBetweenDates(
        userId: Long, 
        startDate: Date, 
        endDate: Date
    ): Flow<List<Transaction>> = 
        transactionDao.getTransactionsBetweenDates(userId, startDate, endDate)
    
    fun getTransactionsByCategory(
        userId: Long, 
        category: String
    ): Flow<List<Transaction>> = 
        transactionDao.getTransactionsByCategory(userId, category)
    
    fun getTotalExpensesBetweenDates(
        userId: Long, 
        startDate: Date, 
        endDate: Date
    ): Flow<Double?> = 
        transactionDao.getTotalExpensesBetweenDates(userId, startDate, endDate)
    
    fun getTotalIncomeBetweenDates(
        userId: Long, 
        startDate: Date, 
        endDate: Date
    ): Flow<Double?> = 
        transactionDao.getTotalIncomeBetweenDates(userId, startDate, endDate)
}