package com.example.budgettrackerapp.di

import com.example.budgettrackerapp.data.dao.BudgetDao
import com.example.budgettrackerapp.data.dao.TransactionDao
import com.example.budgettrackerapp.data.dao.UserDao
import com.example.budgettrackerapp.data.repository.BudgetRepository
import com.example.budgettrackerapp.data.repository.TransactionRepository
import com.example.budgettrackerapp.data.repository.UserRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideUserRepository(userDao: UserDao): UserRepository {
        return UserRepository(userDao)
    }

    @Provides
    @Singleton
    fun provideTransactionRepository(transactionDao: TransactionDao): TransactionRepository {
        return TransactionRepository(transactionDao)
    }

    @Provides
    @Singleton
    fun provideBudgetRepository(budgetDao: BudgetDao): BudgetRepository {
        return BudgetRepository(budgetDao)
    }
}