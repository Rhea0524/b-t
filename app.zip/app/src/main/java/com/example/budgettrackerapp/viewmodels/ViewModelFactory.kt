package com.example.budgettrackerapp.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.budgettrackerapp.repository.BudgetGoalRepository
import com.example.budgettrackerapp.repository.CategoryRepository
import com.example.budgettrackerapp.repository.ExpenseRepository
import com.example.budgettrackerapp.repository.UserRepository

class ViewModelFactory(
    private val userRepository: UserRepository? = null,
    private val categoryRepository: CategoryRepository? = null,
    private val expenseRepository: ExpenseRepository? = null,
    private val budgetGoalRepository: BudgetGoalRepository? = null
) : ViewModelProvider.Factory {
    // ...existing code from guide...
}
