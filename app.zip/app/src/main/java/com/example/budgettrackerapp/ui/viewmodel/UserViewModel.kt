package com.example.budgettrackerapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.budgettrackerapp.data.entities.User
import com.example.budgettrackerapp.data.repository.UserRepository
import com.example.budgettrackerapp.utils.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _updateResult = MutableLiveData<Result<Unit>>()
    val updateResult: LiveData<Result<Unit>> = _updateResult

    fun getCurrentUser(userId: Long): Flow<User?> {
        return userRepository.getUserFlow(userId)
    }

    fun updateUserPreferences(
        userId: Long,
        displayName: String? = null,
        email: String? = null,
        currency: String? = null,
        darkModeEnabled: Boolean? = null,
        notificationsEnabled: Boolean? = null
    ) {
        viewModelScope.launch {
            val result = userRepository.updateUserPreferences(
                userId = userId,
                displayName = displayName,
                email = email,
                currency = currency,
                darkModeEnabled = darkModeEnabled,
                notificationsEnabled = notificationsEnabled
            )
            _updateResult.value = result
        }
    }

    fun updateDarkMode(userId: Long, enabled: Boolean) {
        viewModelScope.launch {
            _updateResult.value = userRepository.updateDarkMode(userId, enabled)
        }
    }

    fun updateNotifications(userId: Long, enabled: Boolean) {
        viewModelScope.launch {
            _updateResult.value = userRepository.updateNotifications(userId, enabled)
        }
    }

    fun updateCurrency(userId: Long, currency: String) {
        viewModelScope.launch {
            _updateResult.value = userRepository.updateCurrency(userId, currency)
        }
    }

    fun updateDisplayName(userId: Long, displayName: String) {
        viewModelScope.launch {
            _updateResult.value = userRepository.updateDisplayName(userId, displayName)
        }
    }

    fun updateEmail(userId: Long, email: String?) {
        viewModelScope.launch {
            _updateResult.value = userRepository.updateEmail(userId, email)
        }
    }

    fun logoutUser() {
        // Clear any user-related data
        viewModelScope.launch {
            // Add any cleanup logic here
        }
    }
}