package com.example.budgettrackerapp.repository

import com.example.budgettrackerapp.data.dao.UserDao
import com.example.budgettrackerapp.data.entities.User

class UserRepository(private val userDao: UserDao) {
    suspend fun registerUser(username: String, password: String): Result<Long> {
        // ...existing code from guide...
        TODO("Implement registerUser")
    }
    suspend fun loginUser(username: String, password: String): Result<User> {
        // ...existing code from guide...
        TODO("Implement loginUser")
    }
}
