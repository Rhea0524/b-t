package com.example.budgettrackerapp.ui.dashboard

import androidx.fragment.app.Fragment

class CategoryDetailFragment : Fragment() {
    // TODO: Implement CategoryDetailFragment as per guide
}
