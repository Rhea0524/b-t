package com.example.budgettrackerapp.ui.fragments

import androidx.fragment.app.Fragment

class AddExpenseFragment : Fragment() {
    // TODO: Implement AddExpenseFragment as per guide
}
