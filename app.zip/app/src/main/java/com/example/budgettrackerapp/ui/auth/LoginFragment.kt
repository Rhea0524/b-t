package com.example.budgettrackerapp.ui.auth

import androidx.fragment.app.Fragment

class LoginFragment : Fragment() {
    // TODO: Implement LoginFragment as per guide
}
