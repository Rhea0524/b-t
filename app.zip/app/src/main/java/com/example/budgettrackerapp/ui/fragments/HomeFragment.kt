package com.example.budgettrackerapp.ui.fragments

import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {
    // TODO: Implement HomeFragment as per guide
}
