package com.example.budgettrackerapp.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.budgettrackerapp.data.entities.User
import com.example.budgettrackerapp.data.repository.UserRepository
import com.example.budgettrackerapp.utils.Result
import com.example.budgettrackerapp.utils.SessionManager
import com.example.budgettrackerapp.utils.Validator
import com.example.budgettrackerapp.ui.state.ValidationResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _loginResult = MutableLiveData<Result<User>>()
    val loginResult: LiveData<Result<User>> = _loginResult

    private val _registerResult = MutableLiveData<Result<Long>>()
    val registerResult: LiveData<Result<Long>> = _registerResult

    fun login(username: String, password: String) {
        viewModelScope.launch {
            val result = userRepository.loginUser(username, password)
            _loginResult.postValue(result)
        }
    }

    fun register(username: String, password: String) {
        viewModelScope.launch {
            val result = userRepository.registerUser(username, password)
            _registerResult.postValue(result)
        }
    }

    fun logout() {
        sessionManager.clearSession()
    }
}