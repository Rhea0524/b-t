package com.example.budgettrackerapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.budgettrackerapp.data.entities.BudgetGoal
import com.example.budgettrackerapp.repository.BudgetGoalRepository
import kotlinx.coroutines.launch

class BudgetGoalViewModel(private val budgetGoalRepository: BudgetGoalRepository) : ViewModel() {
    // ...existing code from guide...
}
