package com.example.budgettrackerapp.data.dao

import androidx.room.*
import com.example.budgettrackerapp.data.entities.Budget
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Insert
    suspend fun insertBudget(budget: Budget)

    @Update
    suspend fun updateBudget(budget: Budget)

    @Delete
    suspend fun deleteBudget(budget: Budget)

    @Query("SELECT * FROM budgets WHERE userId = :userId AND monthYear = :monthYear")
    fun getBudgetsForMonth(userId: Long, monthYear: String): Flow<List<Budget>>

    @Query("SELECT * FROM budgets WHERE userId = :userId AND category = :category AND monthYear = :monthYear LIMIT 1")
    fun getBudgetByCategory(userId: Long, category: String, monthYear: String): Flow<Budget?>

    @Query("SELECT SUM(amount) FROM budgets WHERE userId = :userId AND monthYear = :monthYear")
    fun getTotalBudgetForMonth(userId: Long, monthYear: String): Flow<Double?>
}