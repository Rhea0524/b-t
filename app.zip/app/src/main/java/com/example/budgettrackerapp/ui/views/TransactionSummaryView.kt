package com.example.budgettrackerapp.ui.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.databinding.ViewTransactionSummaryBinding
import com.example.budgettrackerapp.utils.Utils
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class TransactionSummaryView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    private val binding: ViewTransactionSummaryBinding

    init {
        binding = ViewTransactionSummaryBinding.inflate(LayoutInflater.from(context), this)
        updateMonth()
    }

    private fun updateMonth() {
        val formatter = DateTimeFormatter.ofPattern("MMMM yyyy")
        binding.month.text = LocalDate.now().format(formatter)
    }

    fun setCurrentBalance(amount: Double) {
        binding.currentBalance.apply {
            text = Utils.formatCurrency(amount)
            setTextColor(resources.getColor(
                if (amount >= 0) R.color.income_green else R.color.expense_red,
                context.theme
            ))
        }
    }

    fun setIncome(amount: Double) {
        binding.income.text = Utils.formatCurrency(amount)
    }

    fun setExpense(amount: Double) {
        binding.expense.text = Utils.formatCurrency(amount)
    }

    fun updateSummary(currentBalance: Double, income: Double, expense: Double) {
        setCurrentBalance(currentBalance)
        setIncome(income)
        setExpense(expense)
    }
}