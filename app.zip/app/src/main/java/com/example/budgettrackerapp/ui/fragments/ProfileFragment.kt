package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.databinding.FragmentProfileBinding
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import com.example.budgettrackerapp.utils.Result
import com.example.budgettrackerapp.utils.SessionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class ProfileFragment : BaseFragment<FragmentProfileBinding>() {
    private val userViewModel: UserViewModel by viewModels()
    @Inject lateinit var sessionManager: SessionManager
    private var userId: Long = -1L

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentProfileBinding =
        FragmentProfileBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        userId = sessionManager.userId
        if (userId == -1L) {
            findNavController().navigateUp()
            return
        }
        loadUserData()
        setupClickListeners()
        observeUpdateResult()
    }

    private fun loadUserData() {
        viewLifecycleOwner.lifecycleScope.launch {
            userViewModel.getCurrentUser(userId).collect { user ->
                user?.let {
                    binding.editTextDisplayName.setText(it.displayName)
                    binding.editTextEmail.setText(it.email)
                    binding.username.text = "@${it.username}"
                    binding.editTextCurrency.setText(it.currency ?: "USD")
                    binding.switchDarkMode.isChecked = it.darkModeEnabled ?: false
                    binding.switchNotifications.isChecked = it.notificationsEnabled ?: true
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.save_button.setOnClickListener {
            val displayName = binding.editTextDisplayName.text.toString()
            val email = binding.editTextEmail.text.toString()
            val currency = binding.editTextCurrency.text.toString()
            val darkMode = binding.switchDarkMode.isChecked
            val notifications = binding.switchNotifications.isChecked
            userViewModel.updateUserPreferences(
                userId = userId,
                displayName = displayName,
                email = email,
                currency = currency,
                darkModeEnabled = darkMode,
                notificationsEnabled = notifications
            )
        }
        binding.logout_button.setOnClickListener {
            sessionManager.clearSession()
            findNavController().navigateUp()
        }
    }

    private fun observeUpdateResult() {
        userViewModel.updateResult.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Success -> Toast.makeText(context, "Preferences saved", Toast.LENGTH_SHORT).show()
                is Result.Error -> Toast.makeText(context, result.exception.message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}