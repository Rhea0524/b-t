package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.data.entities.Budget
import com.example.budgettrackerapp.databinding.FragmentAddBudgetBinding
import com.example.budgettrackerapp.ui.viewmodel.BudgetViewModel
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@AndroidEntryPoint
class AddBudgetFragment : BaseFragment<FragmentAddBudgetBinding>() {
    
    private val budgetViewModel: BudgetViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentAddBudgetBinding = 
        FragmentAddBudgetBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupCategoryDropdown()
        setupSaveButton()
    }

    private fun setupCategoryDropdown() {
        val categories = listOf(
            "Food & Dining",
            "Transportation",
            "Shopping",
            "Bills & Utilities",
            "Entertainment",
            "Health & Fitness",
            "Travel",
            "Other"
        )
        
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            categories
        )
        
        binding.categoryInput.setAdapter(adapter)
    }

    private fun setupSaveButton() {
        binding.saveButton.setOnClickListener {
            val category = binding.categoryInput.text.toString()
            val amount = binding.amountInput.text.toString().toDoubleOrNull() ?: 0.0

            if (validateInput(category, amount)) {
                saveBudget(category, amount)
            }
        }
    }

    private fun validateInput(category: String, amount: Double): Boolean {
        var isValid = true

        if (category.isBlank()) {
            binding.categoryLayout.error = "Category is required"
            isValid = false
        }

        if (amount <= 0) {
            binding.amountLayout.error = "Amount must be greater than 0"
            isValid = false
        }

        return isValid
    }

    private fun saveBudget(category: String, amount: Double) {
        userViewModel.currentUser.value?.let { user ->
            val currentMonth = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
            
            val budget = Budget(
                userId = user.userId,
                category = category,
                amount = amount,
                monthYear = currentMonth
            )
            
            budgetViewModel.addBudget(budget)
            findNavController().navigateUp()
        }
    }
}