package com.example.budgettrackerapp.ui.auth

import androidx.fragment.app.Fragment

class RegisterFragment : Fragment() {
    // TODO: Implement RegisterFragment as per guide
}
