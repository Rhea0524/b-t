package com.example.budgettrackerapp.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.data.entities.Budget
import com.example.budgettrackerapp.databinding.ItemBudgetBinding
import com.example.budgettrackerapp.utils.Utils

class BudgetAdapter : ListAdapter<Budget, BudgetAdapter.BudgetViewHolder>(BudgetDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BudgetViewHolder {
        val binding = ItemBudgetBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return BudgetViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BudgetViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class BudgetViewHolder(
        private val binding: ItemBudgetBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(budget: Budget) {
            binding.apply {
                budgetCategory.text = budget.category
                budgetAmount.text = "${Utils.formatCurrency(budget.spent)} / ${Utils.formatCurrency(budget.amount)}"
                
                val progress = Utils.calculateProgressPercentage(budget.spent, budget.amount)
                budgetProgress.progress = progress
                
                // Set progress color based on percentage
                val colorRes = when {
                    progress >= 100 -> R.color.budget_progress_exceeded
                    progress >= 80 -> R.color.budget_progress_warning
                    else -> R.color.budget_progress_normal
                }
                budgetProgress.setIndicatorColor(itemView.context.getColor(colorRes))

                val remaining = budget.amount - budget.spent
                budgetRemaining.text = "${Utils.formatCurrency(remaining)} remaining"
                budgetRemaining.setTextColor(
                    itemView.context.getColor(
                        if (remaining >= 0) R.color.income_green else R.color.expense_red
                    )
                )
            }
        }
    }

    private class BudgetDiffCallback : DiffUtil.ItemCallback<Budget>() {
        override fun areItemsTheSame(oldItem: Budget, newItem: Budget): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Budget, newItem: Budget): Boolean {
            return oldItem == newItem
        }
    }
}