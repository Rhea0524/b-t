package com.example.budgettrackerapp.ui.categories

import androidx.fragment.app.Fragment

class CategoriesFragment : Fragment() {
    // TODO: Implement CategoriesFragment as per guide
}
