package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.budgettrackerapp.databinding.FragmentDashboardBinding
import com.example.budgettrackerapp.ui.adapters.BudgetAdapter
import com.example.budgettrackerapp.ui.adapters.TransactionAdapter
import com.example.budgettrackerapp.ui.viewmodel.BudgetViewModel
import com.example.budgettrackerapp.ui.viewmodel.TransactionViewModel
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import java.util.Date

@AndroidEntryPoint
class DashboardFragment : BaseFragment<FragmentDashboardBinding>() {
    
    private val transactionViewModel: TransactionViewModel by viewModels()
    private val budgetViewModel: BudgetViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()
    
    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var budgetAdapter: BudgetAdapter

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentDashboardBinding = 
        FragmentDashboardBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAdapters()
        setupClickListeners()
        observeData()
    }

    private fun setupAdapters() {
        transactionAdapter = TransactionAdapter()
        budgetAdapter = BudgetAdapter()

        binding.recentTransactions.apply {
            adapter = transactionAdapter
            layoutManager = LinearLayoutManager(context)
        }

        binding.budgetOverview.apply {
            adapter = budgetAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    private fun setupClickListeners() {
        binding.viewAllTransactions.setOnClickListener {
            findNavController().navigate(
                DashboardFragmentDirections.actionDashboardToTransactions()
            )
        }

        binding.viewAllBudgets.setOnClickListener {
            findNavController().navigate(
                DashboardFragmentDirections.actionDashboardToBudgets()
            )
        }
    }

    private fun observeData() {
        val calendar = Calendar.getInstance()
        val endDate = calendar.time
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val startDate = calendar.time

        userViewModel.currentUser.observe(viewLifecycleOwner) { user ->
            user?.let {
                transactionViewModel.loadTransactionsByDateRange(
                    userId = it.userId,
                    startDate = startDate,
                    endDate = endDate
                )
                budgetViewModel.loadBudgets(it.userId)
            }
        }

        transactionViewModel.transactions.observe(viewLifecycleOwner) { transactions ->
            transactionAdapter.submitList(transactions.take(5))
        }

        transactionViewModel.totalIncome.observe(viewLifecycleOwner) { income ->
            binding.transactionSummary.setIncome(income)
            updateBalance()
        }

        transactionViewModel.totalExpenses.observe(viewLifecycleOwner) { expenses ->
            binding.transactionSummary.setExpenses(expenses)
            updateBalance()
        }

        budgetViewModel.budgets.observe(viewLifecycleOwner) { budgets ->
            budgetAdapter.submitList(budgets.take(3))
        }
    }

    private fun updateBalance() {
        val income = transactionViewModel.totalIncome.value ?: 0.0
        val expenses = transactionViewModel.totalExpenses.value ?: 0.0
        binding.transactionSummary.setBalance(income - expenses)
    }
}