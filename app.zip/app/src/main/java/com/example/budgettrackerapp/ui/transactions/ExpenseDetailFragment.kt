package com.example.budgettrackerapp.ui.transactions

import androidx.fragment.app.Fragment

class ExpenseDetailFragment : Fragment() {
    // TODO: Implement ExpenseDetailFragment as per guide
}
