package com.example.budgettrackerapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.budgettrackerapp.data.repository.BudgetRepository
import com.example.budgettrackerapp.data.repository.CategoryRepository
import com.example.budgettrackerapp.data.repository.TransactionRepository
import com.example.budgettrackerapp.data.repository.UserRepository
import com.example.budgettrackerapp.utils.SessionManager
import javax.inject.Inject

@Suppress("UNCHECKED_CAST")
class ViewModelFactory @Inject constructor(
    private val userRepository: UserRepository? = null,
    private val categoryRepository: CategoryRepository? = null,
    private val transactionRepository: TransactionRepository? = null,
    private val budgetRepository: BudgetRepository? = null,
    private val sessionManager: SessionManager? = null
) : ViewModelProvider.Factory {
    
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(AuthViewModel::class.java) -> {
                requireNotNull(userRepository) { "UserRepository required for AuthViewModel" }
                requireNotNull(sessionManager) { "SessionManager required for AuthViewModel" }
                AuthViewModel(userRepository, sessionManager) as T
            }
            modelClass.isAssignableFrom(CategoryViewModel::class.java) -> {
                requireNotNull(categoryRepository) { "CategoryRepository required for CategoryViewModel" }
                CategoryViewModel(categoryRepository) as T
            }
            modelClass.isAssignableFrom(TransactionViewModel::class.java) -> {
                requireNotNull(transactionRepository) { "TransactionRepository required for TransactionViewModel" }
                TransactionViewModel(transactionRepository) as T
            }
            modelClass.isAssignableFrom(BudgetViewModel::class.java) -> {
                requireNotNull(budgetRepository) { "BudgetRepository required for BudgetViewModel" }
                BudgetViewModel(budgetRepository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}