package com.example.budgettrackerapp.data.repository

import com.example.budgettrackerapp.data.dao.UserDao
import com.example.budgettrackerapp.data.entities.User
import com.example.budgettrackerapp.utils.Result
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    suspend fun insertUser(user: User): Long {
        return userDao.insertUser(user)
    }

    suspend fun updateUser(user: User) {
        userDao.updateUser(user)
    }

    suspend fun deleteUser(user: User) = userDao.deleteUser(user)

    suspend fun getUserByUsername(username: String): User? {
        return userDao.getUserByUsername(username)
    }

    fun getUserFlow(userId: Long): Flow<User?> {
        return userDao.getUserFlow(userId)
    }

    suspend fun getUser(userId: Long): User? {
        return userDao.getUser(userId)
    }

    suspend fun updateUserPreferences(
        userId: Long,
        displayName: String? = null,
        email: String? = null,
        currency: String? = null,
        darkModeEnabled: Boolean? = null,
        notificationsEnabled: Boolean? = null
    ): Result<Unit> {
        return try {
            displayName?.let { userDao.updateDisplayName(userId, it) }
            email?.let { userDao.updateEmail(userId, it) }
            currency?.let { userDao.updateCurrency(userId, it) }
            darkModeEnabled?.let { userDao.updateDarkMode(userId, it) }
            notificationsEnabled?.let { userDao.updateNotifications(userId, it) }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }

    suspend fun updateDarkMode(userId: Long, enabled: Boolean): Result<Unit> {
        return try {
            userDao.updateDarkMode(userId, enabled)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }

    suspend fun updateNotifications(userId: Long, enabled: Boolean): Result<Unit> {
        return try {
            userDao.updateNotifications(userId, enabled)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }

    suspend fun updateCurrency(userId: Long, currency: String): Result<Unit> {
        return try {
            userDao.updateCurrency(userId, currency)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }

    suspend fun updateDisplayName(userId: Long, displayName: String): Result<Unit> {
        return try {
            userDao.updateDisplayName(userId, displayName)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }

    suspend fun updateEmail(userId: Long, email: String?): Result<Unit> {
        return try {
            userDao.updateEmail(userId, email)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.error(e)
        }
    }
}