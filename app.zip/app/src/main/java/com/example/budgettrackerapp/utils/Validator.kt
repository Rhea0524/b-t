package com.example.budgettrackerapp.utils

import android.util.Patterns
import com.example.budgettrackerapp.ui.state.ValidationResult

object Validator {
    fun validateEmail(email: String?): ValidationResult {
        return when {
            email == null || email.isBlank() -> ValidationResult.Success // Email is optional
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> ValidationResult.Error("Please enter a valid email address")
            else -> ValidationResult.Success
        }
    }

    fun validateAmount(amount: Double): ValidationResult {
        return when {
            amount <= 0 -> ValidationResult.Error("Amount must be greater than 0")
            else -> ValidationResult.Success
        }
    }

    fun validateUsername(username: String): ValidationResult {
        return when {
            username.isBlank() -> ValidationResult.Error("Username cannot be empty")
            username.length < 3 -> ValidationResult.Error("Username must be at least 3 characters long")
            !username.matches(Regex("^[a-zA-Z0-9._-]+$")) -> ValidationResult.Error("Username can only contain letters, numbers, dots, underscores and hyphens")
            else -> ValidationResult.Success
        }
    }

    fun validatePassword(password: String): ValidationResult {
        return when {
            password.isBlank() -> ValidationResult.Error("Password cannot be empty")
            password.length < 6 -> ValidationResult.Error("Password must be at least 6 characters long")
            !password.matches(Regex(".*[A-Z].*")) -> ValidationResult.Error("Password must contain at least one uppercase letter")
            !password.matches(Regex(".*[a-z].*")) -> ValidationResult.Error("Password must contain at least one lowercase letter")
            !password.matches(Regex(".*\\d.*")) -> ValidationResult.Error("Password must contain at least one number")
            else -> ValidationResult.Success
        }
    }

    fun validateBudgetCategory(category: String): ValidationResult {
        return when {
            category.isBlank() -> ValidationResult.Error("Category cannot be empty")
            else -> ValidationResult.Success
        }
    }

    fun validateTransactionDescription(description: String): ValidationResult {
        return when {
            description.isBlank() -> ValidationResult.Error("Description cannot be empty")
            description.length > 100 -> ValidationResult.Error("Description is too long")
            else -> ValidationResult.Success
        }
    }

    fun validateDisplayName(displayName: String?): ValidationResult {
        return when {
            displayName == null || displayName.isBlank() -> ValidationResult.Success // Display name is optional
            displayName.length < 2 -> ValidationResult.Error("Display name must be at least 2 characters long")
            displayName.length > 50 -> ValidationResult.Error("Display name must not exceed 50 characters")
            else -> ValidationResult.Success
        }
    }

    fun validateCurrency(currency: String): ValidationResult {
        // Add common currency codes - can be expanded
        val validCurrencies = setOf("USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "INR")
        return when {
            !validCurrencies.contains(currency.uppercase()) -> ValidationResult.Error("Invalid currency code")
            else -> ValidationResult.Success
        }
    }
}