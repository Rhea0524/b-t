package com.example.budgettrackerapp.ui.expenses

import androidx.fragment.app.Fragment

class AddExpenseFragment : Fragment() {
    // TODO: Implement AddExpenseFragment as per guide
}
