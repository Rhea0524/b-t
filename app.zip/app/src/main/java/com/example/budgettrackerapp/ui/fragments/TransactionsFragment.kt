package com.example.budgettrackerapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuProvider
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.databinding.FragmentTransactionsBinding
import com.example.budgettrackerapp.ui.adapters.TransactionAdapter
import com.example.budgettrackerapp.ui.viewmodel.TransactionViewModel
import com.example.budgettrackerapp.ui.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class TransactionsFragment : BaseFragment<FragmentTransactionsBinding>(), MenuProvider {
    
    private val transactionViewModel: TransactionViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()
    private lateinit var transactionAdapter: TransactionAdapter

    override fun getViewBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ): FragmentTransactionsBinding = 
        FragmentTransactionsBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupMenu()
        setupRecyclerView()
        setupClickListeners()
        observeData()
    }

    private fun setupMenu() {
        requireActivity().addMenuProvider(this, viewLifecycleOwner)
    }

    private fun setupRecyclerView() {
        transactionAdapter = TransactionAdapter()
        binding.transactionsList.apply {
            adapter = transactionAdapter
            layoutManager = LinearLayoutManager(context)
        }
    }

    private fun setupClickListeners() {
        binding.fabAddTransaction.setOnClickListener {
            findNavController().navigate(
                TransactionsFragmentDirections.actionTransactionsToAddTransaction()
            )
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            userViewModel.currentUser.collect { user ->
                user?.let {
                    transactionViewModel.loadTransactions(it.userId)
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            transactionViewModel.transactions.collect { transactions ->
                transactionAdapter.submitList(transactions)
            }
        }
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menuInflater.inflate(R.menu.menu_transaction_filters, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when (menuItem.itemId) {
            R.id.filter_all -> {
                transactionViewModel.clearFilters()
                true
            }
            R.id.filter_income -> {
                transactionViewModel.filterByType(TransactionType.INCOME)
                true
            }
            R.id.filter_expense -> {
                transactionViewModel.filterByType(TransactionType.EXPENSE)
                true
            }
            R.id.sort_date_desc -> {
                transactionViewModel.sortByDate(descending = true)
                true
            }
            R.id.sort_date_asc -> {
                transactionViewModel.sortByDate(descending = false)
                true
            }
            R.id.sort_amount_desc -> {
                transactionViewModel.sortByAmount(descending = true)
                true
            }
            R.id.sort_amount_asc -> {
                transactionViewModel.sortByAmount(descending = false)
                true
            }
            else -> false
        }
    }
}