package com.example.budgettrackerapp.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.budgettrackerapp.data.entities.Budget
import com.example.budgettrackerapp.data.repository.BudgetRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BudgetViewModel @Inject constructor(
    private val budgetRepository: BudgetRepository
) : ViewModel() {
    private val _budgets = MutableStateFlow<List<Budget>>(emptyList())
    val budgets: StateFlow<List<Budget>> = _budgets

    private val _operationStatus = MutableStateFlow<Result<Unit>?>(null)
    val operationStatus: StateFlow<Result<Unit>?> = _operationStatus

    fun loadBudgets(userId: Long) {
        viewModelScope.launch {
            budgetRepository.getAllBudgetsForUser(userId).collect { budgetList ->
                _budgets.value = budgetList
            }
        }
    }

    fun loadBudgetsForMonth(userId: Long, monthYear: String) {
        viewModelScope.launch {
            budgetRepository.getBudgetsForMonth(userId, monthYear).collect { budgetList ->
                _budgets.value = budgetList
            }
        }
    }

    fun addBudget(budget: Budget) {
        viewModelScope.launch {
            try {
                budgetRepository.insertBudget(budget)
                _operationStatus.value = Result.success(Unit)
            } catch (e: Exception) {
                _operationStatus.value = Result.failure(e)
            }
        }
    }

    fun updateBudget(budget: Budget) {
        viewModelScope.launch {
            try {
                budgetRepository.updateBudget(budget)
                _operationStatus.value = Result.success(Unit)
            } catch (e: Exception) {
                _operationStatus.value = Result.failure(e)
            }
        }
    }

    fun deleteBudget(budget: Budget) {
        viewModelScope.launch {
            try {
                budgetRepository.deleteBudget(budget)
                _operationStatus.value = Result.success(Unit)
            } catch (e: Exception) {
                _operationStatus.value = Result.failure(e)
            }
        }
    }
}