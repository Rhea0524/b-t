package com.example.budgettrackerapp.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val sharedPref: SharedPreferences =
        context.getSharedPreferences("BudgetPref", Context.MODE_PRIVATE)

    fun saveAuthToken(token: String) {
        sharedPref.edit().putString("AUTH_TOKEN", token).apply()
    }
}