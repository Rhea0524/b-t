package com.example.budgettrackerapp.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.budgettrackerapp.R
import com.example.budgettrackerapp.data.AppDatabase
import com.example.budgettrackerapp.databinding.FragmentLoginBinding
import com.example.budgettrackerapp.repository.UserRepository
import com.example.budgettrackerapp.utils.SessionManager
import com.example.budgettrackerapp.viewmodels.AuthViewModel
import com.example.budgettrackerapp.viewmodels.ViewModelFactory

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    private lateinit var authViewModel: AuthViewModel
    private lateinit var sessionManager: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize session manager
        sessionManager = SessionManager(requireContext())

        // Check if user is already logged in
        if (sessionManager.isLoggedIn()) {
            navigateToHome()
            return
        }

        // Initialize ViewModel
        val database = AppDatabase.getDatabase(requireContext())
        val userRepository = UserRepository(database.userDao())
        val factory = ViewModelFactory(userRepository = userRepository)
        authViewModel = ViewModelProvider(this, factory)[AuthViewModel::class.java]

        // Setup login button
        binding.btnLogin.setOnClickListener {
            login()
        }

        // Setup register link
        binding.tvRegisterLink.setOnClickListener {
            findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }

        // Observe login result
        authViewModel.loginResult.observe(viewLifecycleOwner) { result ->
            result.onSuccess { user ->
                sessionManager.saveUserSession(user.userId, user.username)
                navigateToHome()
            }.onFailure { exception ->
                Toast.makeText(requireContext(), exception.message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun login() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        authViewModel.login(username, password)
    }

    private fun navigateToHome() {
        findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}